package perpustakaan;

public class NonFiksi {
}
