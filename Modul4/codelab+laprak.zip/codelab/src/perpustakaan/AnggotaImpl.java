package perpustakaan;

public class AnggotaImpl extends Anggota {
    public AnggotaImpl(String nama, String idAnggota) {
        super(nama, idAnggota);
    }
}
