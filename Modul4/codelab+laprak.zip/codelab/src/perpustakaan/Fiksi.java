package perpustakaan;

public class Fiksi {
}
